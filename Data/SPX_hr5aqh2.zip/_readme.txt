SPX (S&P 500)  DataSet
==========================================
 
Dataset Dates :27-Apr-2007 - 29-Jan-2021

Timeframes : 1-minute, 5-minutes, 30-minutes, 1-hour


File Format : {DateTime, Open, High, Low, Close}  
 
- Excel will usually fail to open large files directly. 
  To use the data in Excel, open the files using notepad and then break into smaller files or copy/paste into Excel
- Data license is available at https://firstratedata.com/about/license


___________________________
copyright FirstRateData.com